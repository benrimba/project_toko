<div class="container">
	<div class="row">
	  <div class="col-sm-4">
	  	<?php 
	  		if($_GET['edit']=='edit-kategori'){
	  			$sqledit = $con->query("SELECT*FROM tbkategori WHERE kdkat='$_GET[id]'");
	  			$rview=$sqledit->fetch_array();
	  			?>
	  	<div class="card">
		  <div class="card-header bg-info text-white">Edit Data Kategori</div>
			  <div class="card-body">
				<form action="" method="POST">
					<input type="hidden" value="<?=$rview['kdkat']?>"  name="kd">
				  <div class="form-group">
					<label for="pwd">Kategori</label>
					<input type="text" class="form-control form-control-sm" value="<?=$rview['kategori']?>" placeholder="Masukan Kategori" name="mn">
				  </div>				  
				  <button type="submit" class="btn btn-info" name="btnedit">Update</button>
				</form> 			  
			  </div>
		  <div class="card-footer bg-info text-white"></div>
		</div> 
	  <?php
	  	if(isset($_POST['btnedit'])){
	  		$sqlpro = $con->query("UPDATE tbkategori SET kategori='$_POST[mn]' WHERE kdkat='$_POST[kd]'");
	  		if($sqlpro){
	  				echo"<script>alert('Data Berhasil Di rubah');document.location.href='?page=menu';</script>";
	  		}else{
	  			echo"<script>alert('Gagal Di rubah');document.location.href='?page=menu';</script>";
	  		}
	  	}
	  		}else{
	  	 ?>
	    <div class="card">
		  <div class="card-header bg-info text-white">Input Data Kategori</div>
			  <div class="card-body">
				<form action="" method="POST">
				  <div class="form-group">
					<label for="pwd">Kategori</label>
					<input type="text" class="form-control form-control-sm" placeholder="Masukan Kategori" name="mn">
				  </div>				  
				  <button type="submit" class="btn btn-info" name="btn">Insert</button>
				</form> 			  
			  </div>
		  <div class="card-footer bg-info text-white"></div>
		</div> 
	<?php } ?>
	</div>
	<?php 
		if(isset($_POST['btn'])){
			$a = $_POST['mn'];
			$sql=$con->query("INSERT INTO tbkategori VALUES('','$a')");
			if($sql){
				echo"<script>alert('Data Berhasil masuk.');</script>";
			}else{
				echo"<script>alert('Data Gagal masuk.');</script>";
			}
		}
	 ?>		  
	<div class="col-sm-8">
		<div class="card">
		  <div class="card-header bg-info text-white">Output Data Kategori</div>
			  <div class="card-body">
					<table class="table table-sm">
						<thead class="thead-light">
						  <tr>
							<th>No</th>
							<th>Kategori</th>
							<th>Aksi</th>
						  </tr>
						</thead>
						<tbody>
						<?php 
							$no = 0;
							$sqli = $con->query("SELECT*FROM tbkategori");
							while ($resl=$sqli->fetch_array()) {
								?>
							<tr>
							<td><?=$no=$no+1?></td>
							<td><?=$resl['kategori']?></td>
							<td><a href="?page=menu&edit=edit-kategori&id=<?=$resl['kdkat']?>" class="btn btn-success btn-sm">Ubah</a> || <a href="?page=menu&hapus=hapus-kategori&id=<?=$resl['kdkat']?>"  class="btn btn-danger btn-sm">Hapus</a></td>
						  	</tr>
							<?php	
							}
							if($_GET['hapus']=='hapus-kategori'){
							$sqlhapus = $con->query("DELETE FROM tbkategori WHERE kdkat='$_GET[id]'");
							if($sqlhapus){
	  							echo"<script>document.location.href='?page=menu';</script>";
					  		}else{
					  			echo"document.location.href='?page=menu';</script>";
					  		}
					  		}
						 ?>
						  
						 </tbody>
					  </table>	  
			  </div>
		  <div class="card-footer bg-info text-white"></div>
		</div> 	  	  
	</div>
</div>  
</div>