<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="asset/css/bootstrap.min.css" >
    <style type="text/css">
    	.col-centered{
    		display: inline-block;
    		float: none;
    		margin-left: 32%;
    		margin-top: 5%;
    		width: 100%;
    	}
    </style>
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-4 col-centered">
				<div class="card">
					<div class="card-header card bg-success text-white text-center">Silahkan Login Disini</div>
					   <div class="card-body">
					   	<form action="" method="POST">
							  <div class="form-group">
							    <label for="email">Username</label>
							    <input type="text" class="form-control" name="usr" placeholder="Masukan Username" >
							  </div>
							  <div class="form-group">
							    <label for="pwd">Password:</label>
							    <input type="password" class="form-control" name="pwd" placeholder="Masukan Password">
							  </div>
							  <button type="submit" name="btn" class="btn btn-success">LOGIN</button>
						</form>
						<?php 
							if(isset($_POST['btn'])){
								$a = $_POST['usr'];
								$b = md5($_POST['pwd']);
								$SQL= $con->query("SELECT*FROM tbuser WHERE username='$a' AND password='$b'");
								$rv =  $SQL->fetch_array();
								$rows = $SQL->num_rows;
								if($rows > 0){
									session_start();
									$_SESSION['user'] = $rv['username'];
									echo"<script>document.location.href='index.php'</script>";
								}else{
									echo"<script>alert('Terjadi Kesalahan');document.location.href='index.php'</script>";
								}
							}
						 ?> 
					   </div>
					<div class="card-footer card bg-success text-white text-center"></div>
				</div>
			</div>					
		</div>
	</div>
</body>
</html>
