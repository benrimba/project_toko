<?php 
session_start();
if($_SESSION['user']){
	session_destroy();
	echo"<script>document.location.href='index.php'</script>";
}
 ?>